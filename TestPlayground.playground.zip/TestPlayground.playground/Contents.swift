struct Person {
    var name : String
    var age: String
    var address : String
}

let listPerson = [
    Person(name: "linh", age: "30", address: "LD"),
    Person(name: "lan", age: "25", address: "HN"),
    Person(name: "linh", age: "30", address: "LD"),
    Person(name: "HUng", age: "10", address: "VN"),
    Person(name: "Nam", age: "15", address: "XM"),
]

extension Array {
    func unique<T:Hashable>(map: ((Element) -> (T)))  -> [Element] {
        var set = Set<T>() //the unique list kept in a Set for fast retrieval
        var arrayOrdered = [Element]() //keeping the unique list of elements but ordered
        for value in self {
            if !set.contains(map(value)) {
                set.insert(map(value))
                arrayOrdered.append(value)
            }
        }
        
        return arrayOrdered
    }
}

let uniqueMessages = listPerson.unique{$0.name}
uniqueMessages.map { Person in
    print(Person)
}

